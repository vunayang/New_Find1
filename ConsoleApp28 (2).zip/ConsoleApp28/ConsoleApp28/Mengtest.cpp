﻿<?xml version="1.0" encoding="utf-8" ?> 
<xs:schema id="Mengtest" 
                  targetNamespace="http://tempuri.org/Mengtest.xsd"
                  elementFormDefault="qualified"
                  attributeFormDefault="qualified"
                  xmlns="http://tempuri.org/Mengtest.xsd"
                  xmlns:mstns="http://tempuri.org/Mengtest.xsd"
                  xmlns:xs="http://www.w3.org/2001/XMLSchema"
                  xmlns:msdata="urn:schemas-microsoft-com:xml-msdata"
                  xmlns:msprop="urn:schemas-microsoft-com:xml-msprop">
    <xs:element name="Mengtest" msdata:IsDataSet="true" msdata:UseCurrentLocale="true" msprop:EnableTableAdapterManager="true">
        <xs:complexType>
            <xs:choice minOccurs="0" maxOccurs="unbounded"></xs:choice>
        </xs:complexType>
    </xs:element>
</xs:schema>
                                                                 